# Sổ tay series: „NACHTZUG – Was würdest du tun?“

## Ý tưởng series (1 câu)
Mỗi tập, bạn (ICH) ngồi trên một chuyến tàu đêm ở Đức. Tàu dừng giữa chỗ không người, một mối nguy có thật xuất hiện, và cuối tập bạn phải chọn một trong hai.

## Luật của series (áp dụng mọi tập, ngoài `CLAUDE.md`)
- **Góc nhìn:** POV fisheye của ICH. ICH nói ít (3–5 câu mỗi tập), không bao giờ thấy mặt, chỉ thấy tay và tay áo (áo khoác vải dù màu xanh rêu, cố định cho cả series).
- **Mở đầu:** khung hình 0 luôn có mối nguy nhìn thấy được trong toa tàu; tiếng động đầu tiên < 1 s.
- **Nhịp:** cứ 2–4 s một câu, 18–25 s một cú lật, 5–6 cú lật mỗi tập.
- **Kết:** thẻ „Was würdest du tun?“ với A/B, kèm một **mối đe doạ mới chưa được giải thích** → tiêu đề tập sau trên thẻ.
- **Hạt nhân thật:** mỗi tập dựa trên một hiện tượng có thật ở Đức (trộm cáp, thời tiết, động vật sổng chuồng, lừa đảo…), nhưng người, tên, tuyến tàu là hư cấu. Không dùng logo, đồng phục hay tên thương hiệu của công ty đường sắt thật.
- **Tông:** căng thẳng, không máu me, không bạo lực trực tiếp; nỗi sợ đến từ lạnh, bóng tối, lòng tin.
- **Ngôn ngữ:** thoại tiếng Đức đời thường; tránh từ thô tục trong cả tập (an toàn kiếm tiền).

## Bối cảnh cố định
- **Tàu:** „RE 47“ (hư cấu), tàu khu vực 2 toa chạy đêm qua vùng rừng núi. Toa 2: ghế đôi, cửa giữa toa, nhà vệ sinh cuối toa, đèn khẩn cấp màu cam.
- Cần **plan.md cho Toa 2** (cửa trượt ra ngoài, vị trí ghế, cửa sổ, tay nắm mở cửa khẩn cấp „Notentriegelung“) **trước khi dựng tập 1**.

## Nhân vật (cần turnaround phong cách D + duyệt trước khi dùng)
| Nhân vật | Vai | Ngoại hình (đề xuất) | Mong muốn | Bí mật / điều có thể mất | Trạng thái sau tập 1 |
|---|---|---|---|---|---|
| **ICH** | người kể, ~20 | chỉ thấy tay, áo xanh rêu, điện thoại có ốp cam | về nhà an toàn | đã **quay video** mọi thứ → giờ là nhân chứng, có thể thành mục tiêu | đứng cạnh cửa, phải chọn |
| **Hanna Roth** | trưởng tàu, ~50 | tóc ngắn muối tiêu, áo khoác đồng phục hư cấu màu đỏ đô, bộ đàm | giữ mọi người an toàn, theo quy định | ca thứ ba liên tiếp vì thiếu người, sợ mất việc | tin ICH, sợ Brandt |
| **Herr Brandt** | hành khách, ~65, cựu nhân viên trạm tín hiệu (Stellwerk) | áo khoác len dày màu nâu, mũ lưỡi trai vải, ria mép trắng | bảo vệ con trai | **là người chỉ điểm cho băng trộm cáp** (biết lịch tàu, vị trí cáp), vì nợ nần | bị lộ, tay ở tay nắm cửa khẩn cấp |
| **Lotte** | hành khách, 17 | tóc tết hai bên, áo phao vàng chanh, tai nghe chụp | được chú ý, giúp người | livestream mọi thứ → **kênh của cô đã bị băng nhóm theo dõi** | sợ hãi, chat là nguồn tin |
| **Jonas Brandt** („Fremder“) | con trai Brandt, ~28 | mũ len đen dính tuyết, áo khoác công nhân cam bạc màu | thoát khỏi băng | là thành viên băng, bị bỏ lại; có thể khai ra tất cả | sắp chết cóng ngoài cửa |
| **„Die Bande“** | băng trộm cáp | chỉ thấy xe tải không đèn, đèn pin, chat ẩn danh | lấy cáp, không để lại nhân chứng | ai là kẻ cầm đầu? ai trong chat? | đang theo dõi Toa 2 |

Kiểm tra trùng: Hanna/Brandt/Lotte/Jonas phải khác **mọi** nhân vật trong Figuren-Register ở ≥ 4/6 đặc điểm – viết bảng so sánh trước khi render.

## Các mạch truyện mở (phải trả lời ở tập sau)
1. Ai viết „Wir sehen euch. Wagen zwei.“ trong chat của Lotte? (câu hỏi chính tập 2)
2. ICH chọn A hay B? → tập 2 có **hai phiên bản mở đầu**, hoặc lấy lựa chọn đa số từ bình luận.
3. Xe tải không đèn chở gì, ngoài cáp?
4. Brandt nợ ai, nợ bao nhiêu?
5. Video trong máy ICH – bằng chứng hay án tử?

## Kế hoạch tập
| Tập | Tiêu đề | Hạt nhân thật | Câu hỏi trung tâm | Kết / dilemma |
|---|---|---|---|---|
| 01 | **Kabelklau** | trộm cáp tín hiệu làm tàu dừng | Người gõ cửa là nạn nhân hay kẻ trộm? | Mở cửa cứu Jonas hay để đóng? → „Wer schreibt im Chat?“ |
| 02 | **Wer schreibt im Chat?** | theo dõi qua livestream / định vị | Ai trong toa đang báo vị trí cho băng? | Giao điện thoại có video cho băng để cứu mọi người, hay giấu nó? |
| 03 | **Funkloch** | mất sóng trong hầm / trên núi | Làm sao gọi cứu hộ khi không có sóng? | Đi bộ dọc đường ray tới trạm tín hiệu, hay ở lại toa lạnh? |
| 04 | **Die Aussage** | bảo vệ nhân chứng | ICH có dám làm chứng chống băng? | Khai tên Brandt (cứu mình) hay im lặng (cứu Jonas)? |

## Lưu ý sản xuất
- Thứ tự: plan.md Toa 2 → turnaround 4 nhân vật mới (phong cách D) → duyệt → giọng (ElevenLabs, tiếng Đức) → dựng → kiểm tra mỗi 2 s.
- Giọng cố định cho cả series: lưu trong `scenes/nachtzug-01/voices.json`, các tập sau dùng lại.
- Âm thanh tự tạo: gió tuyết, tiếng gõ kính, kim loại kêu răng rắc vì lạnh, máy sưởi tắt, bộ đàm rè.
