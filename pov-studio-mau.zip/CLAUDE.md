# Mein POV-Kanal

> Toàn bộ quy trình từng bước: **`QUY-TRINH.md`** (đọc trước khi bắt đầu dự án/video mới).

## Kommunikation
- Antworten an mich immer auf **Vietnamesisch** (tiếng Việt).

## Format
- Horizontal 16:9, 1920 × 1080, **30 fps**
- Sprache der Figuren: **Deutsch**
- Ich-Perspektive mit 0.5x-Fisheye
- Länge: 1:45 bis 2:15
- Nie mit schwarzem Bild starten. Die Gefahr ist schon in Frame 0 sichtbar.
- Erster Knall vor Sekunde 5.
- Alle 2 bis 4 s eine Dialogzeile.
- Ende mit Dilemma: „Was würdest du tun?“ mit 2 Optionen.

## Quy tắc sản xuất & Tuân thủ YouTube
- **Định dạng:** Khung ngang 16:9 (`1920x1080`).
- **Chống trùng lặp:** Mỗi video phải có cốt truyện riêng, góc quay và nhịp dựng khác biệt, lời thoại có cảm xúc; không sản xuất rập khuôn hàng loạt.
- **An toàn nội dung (Phim giật gân/Hoạt hình):** Không máu me cận cảnh, bạo lực cực đoan, tự hại, thù ghét, gợi dục hay nội dung độc hại cho trẻ em. 30 giây đầu tuyệt đối sạch (không từ thô tục, không yếu tố nhạy cảm) để đảm bảo bật kiếm tiền xanh.
- **Bản quyền:** Chỉ dùng hình ảnh, giọng nói, nhạc và SFX tự tạo hoặc miễn phí bản quyền; không giả giọng người thật hay dùng nhân vật có bản quyền.
- **Metadata & Nhãn AI:** Tiêu đề/mô tả/tags phải đúng nội dung video; nhắc tôi bật nhãn "Nội dung đã chỉnh sửa hoặc tổng hợp" (AI) khi đăng lên YouTube Studio nếu có yếu tố chân thực.

### Cách áp dụng trong dự án
- Mỗi video có file `scenes/<id>/metadata.md`: tiêu đề, mô tả, tags (khớp nội dung) + dòng nhắc bật nhãn AI.
- Trước khi xuất bản: kiểm tra 30 giây đầu (lời thoại, phụ đề, hình ảnh) không có từ thô tục hay yếu tố nhạy cảm.
- SFX trong dự án được tự tạo bằng code (`scripts/*_assets.py`). Giọng ElevenLabs chỉ dùng giọng trong thư viện, **không** dùng giọng mô phỏng người thật hoặc người nổi tiếng.
- Video mới phải khác video trước về cốt truyện, địa điểm/góc quay và nhịp dựng (so với các `scenes/*/timeline.json` đã có).

## Stil
Fester Kanal-Stil: **D · Comic-Linie** (abgeleitet aus `references/` Bild 11–16, nur Stil). Gewählt am 24.11.2026, ersetzt B · Soft-3D.
Code: `src/stile/richtungen.ts` → `KANAL_STIL` (Eintrag `comic-linie`). Figuren, Turnarounds und Szenen verwenden automatisch diesen Stil. Werte unten sind verbindlich.
Stilprobe neu rendern: `npm run render:stile -- comic-linie` → `out/stile/tafel-comic-linie.png`.

### Outline
- **Jede Form hat eine Outline** (Inverted Hull, an der Normalen aufgeblasene Rückseiten).
- Dicke Figuren: **0.012 Figuren-Einheiten** (Gesichtsteile ×0.45). Dicke Raum/Möbel: **0.015 m**.
- Farbe: **`#2d2622`** (warmes Dunkelbraun) – **nie reines Schwarz**, nie aus der Teilfarbe abgeleitet.
- **Dünne, dunkle Teile ohne Outline** (`outline={0}`): Brillengestelle, Kabel, Bügel – sonst werden sie zu dicken Balken.

### Licht & Schatten
- **Flach, genau 2 Töne:** `steps: 2`, Übergangsbreite **0.012** → harte, aber nicht gezackte Kante. Kein Verlauf.
- Hauptlicht-Richtung: `[-0.5, 0.75, 0.8]` (oben links vorne).
- Schatten-Multiplikator (linear): **`[0.82, 0.72, 0.74]`** → Schatten warm-rosa, nie grau oder blau.
- **Keine Randlichter** (`rim: 0`, keine `rimLights`).

### Glanzlichter
- Körper, Kleidung, Haare: **kein Glanz** (Stärke 0.001).
- Nur Augen: kleiner scharfer Lichtpunkt (Stärke 0.9, Exponent 90, Härte 0.8) + weißer Punkt oben links, 11 % der Augenbreite.

### Texturen
- **Papierkorn 0.05** auf allen Flächen (außer Augen). Keine Hautunebenheit (Bump 0), kein Strickmuster (Stoff 0), kein Halbton.

### Farbkorrektur (auf das fertige Bild)
- CSS-Filter `saturate(0.95) contrast(1.04)` – gilt für Turnarounds und POV-Szenen gleich.

### Farbpalette (Licht → Schatten)
| Element | Licht | Schatten |
|---|---|---|
| Hintergrund Turnaround | Verlauf `#f1e9dc` → `#e9dfcf` (Papier) | – |
| Himmel in POV-Szenen | Verlauf `#a9c6d6` → `#d3e1e2` → `#efe9dc` | – |
| Beschriftung / Linie | `#2d2622` | `#281f1c` |
| Papier | `#efe7da` | `#dbc8bf` |
| Senf | `#b97e2c` | `#a96c25` |
| Dunkelgrün | `#2d3128` | `#282922` |
| Lachs | `#e48c74` | `#d17865` |
| Rot (Signal) | `#b52330` | `#a61d29` |
| Jeans | `#5a7aa0` | `#52698b` |
| Wangenröte | `#e8907a`, Deckkraft **36 %** (blush 0.6 × 0.6) | `#d47c6a` |
| Mund | `#a4524b` | – |
| Augenweiß | `#f8f5ef` | – |
| Pupille | `#140f0c` | – |

Figurenfarben (Kleidung, Haare, Iris) legt jede Figur selbst fest → siehe Figuren-Register.
Regel: gedämpfte, erdige Töne + **genau eine** kräftige Akzentfarbe pro Figur. **Helle Haare nicht beige/hautnah wählen**: der warme Schatten macht sie sonst hautfarben (Fehler bei der Stilprobe).

### Hauttöne (Licht → Schatten in diesem Licht)
| Stufe | Licht | Schatten |
|---|---|---|
| 1 hell | `#f6dcc8` | `#e1beaf` |
| 2 hell-warm | `#efc4a6` | `#dba991` |
| 3 mittel | `#dba783` | `#c99072` |
| 4 gebräunt | `#c68a62` | `#b57755` |
| 5 braun | `#a0663f` | `#925736` |
| 6 dunkel | `#6e4429` | `#643a23` |
- Nase: Hautton etwas röter (z. B. Stufe 2 → `#eab093`).

### Augenform
- Bauchige Ellipsoide, aus dem Kopf gewölbt: Augenbreite **48 % des Kopfradius** (Halbachse 24 %), Höhe = Breite × 1.13, Tiefe = Breite × 0.73.
- Abstand: je **±0.34 rad** (≈ 19,5°) von der Gesichtsmitte, auf Augenhöhe (Kopfmitte).
- Iris **58 %** der Augenbreite, Pupille **28 %**, beide leicht zur Nase versetzt.
- Oberlid hautfarben; Lid-Rotation je Figur (−1.2 offen … −0.4 schwer), Standard −0.85.

### Proportionen
- **Kopf : Körper = 1 : 4.5** (Kopfhöhe 0.53 bei 2.35 Gesamthöhe ohne Kopfbedeckung).
- Großer Kopf, **dünner Hals** (Radius 17 % des Kopfradius), lange dünne Beine, klobige Schuhe.
- Erlaubte Abweichung pro Figur: Kopf : Körper zwischen **1 : 4 und 1 : 5.5**.

### Ansichten & Render
- Turnaround: orthografische Kamera, Figur von y≈130 px bis y≈1010 px (bei 1080p), Papier-Hintergrund.
- Nahaufnahme: Perspektive, FOV 20°, Kamera 3.1–3.4 Einheiten vor dem Kopf, Kopf samt Haar ganz im Bild.
- Einzelbilder mit `--scale=2` (3840 × 2160), 3D in 4K immer `--concurrency=1`.
- POV-Szenen: Raum und Möbel bekommen dieselbe Outline (0.015 m); Himmel und Farbkorrektur wie oben.

## Figuren-Regeln
1. **Jede neue Figur bekommt in diesem Stil zuerst einen Turnaround (frontal, 3/4, seitlich) und eine Nahaufnahme des Gesichts, bevor sie in einem Video eingesetzt wird.** Erst nach Freigabe ins Register eintragen.
2. **Keine zwei Figuren dürfen sich ähneln.** Jede neue Figur muss sich von **jeder** Figur im Register in mindestens **4 der 6** Merkmale unterscheiden:
   1. Silhouette (Kopfbedeckung bzw. Frisurform)
   2. Haarfarbe
   3. Hauptfarbe der Kleidung (Oberteil)
   4. Akzentfarbe
   5. Markenzeichen-Accessoire
   6. Körperbau und Proportion (Kopf:Körper, Größe, Statur)
   Zusätzlich: andere Hautton-Stufe **oder** andere Augenfarbe.
3. Vor dem Rendern einer neuen Figur den Vergleich mit dem Register hinschreiben.
4. Keine Figur aus `references/` kopieren – nur Stil.

## Figuren-Register
| Figur | Status | Silhouette | Haare | Oberteil | Akzent | Accessoire | Körper | Haut | Augen |
|---|---|---|---|---|---|---|---|---|---|
| **Juno** (`src/juno/Juno.tsx`) | in Stil B freigegeben – neuer Turnaround in Stil D nötig | Strickmütze `#c99a2e` mit orangem Anstecker `#d9632f`, Bob | dunkelbraun `#2e211b` | Strickpullover rost `#b5532a`, Cargohose oliv `#5f6446` | Senfgelb `#c99a2e` / `#d2a23a` | runde Brille `#2a2421`, Sofortbildkamera, Kopfhörer, Umhängetasche `#3f4a33` | 1 : 4.5, schlank | Stufe 2 `#efc4a6` + Sommersprossen `#b4704f` | haselbraun `#6b5a2e` |
| **Frau Weber** (Lehrerin) | Turnaround in Stil D fertig, wartet auf Freigabe | hoher Dutt | aschgrau `#9a948c` | Strickjacke pflaume `#6e4058` über Bluse `#efe6d6`, langer Rock `#3a393f` | Petrol `#3f8a83` | eckige Brille, Schal, Tasse, Marker, Uhr | 1 : 5.5, groß | Stufe 1 `#f6dcc8` | graublau `#627585` |
| **Carol** | Turnaround in Stil D fertig, wartet auf Freigabe | lange glatte Haare + Haarreif | rotblond `#b8572f` | Hoodie lavendel `#a99bd0`, Jeans hell `#8daccc` | Koralle `#ef7b6b` | Haarreif, Scrunchie | 1 : 4, klein, zierlich | Stufe 1 `#f6dcc8` | grün `#4f8a5b` |
| **Rafa** | Turnaround in Stil D fertig, wartet auf Freigabe | Afro | schwarzbraun `#1d1713` | College-Jacke blau `#2f4f9a`, Ärmel creme `#ece3d2` | Rot `#c8433a` | Silberkette, Uhr, rote High-Tops | 1 : 5, groß, schlaksig | Stufe 5 `#a0663f` | dunkelbraun `#3d2618` |
| **Leo** | Turnaround in Stil D fertig, wartet auf Freigabe | Cap verkehrt herum | blond `#d9b46a` | offenes Hemd khaki `#b9925e` über weißem Shirt, schwarze Jeans | Schwarz `#24242a` | Cap, ein Ohrstöpsel | 1 : 4.5, breit | Stufe 3 `#dba783` | blau `#4b7fb0` |
| **Bia** | Turnaround in Stil D fertig, wartet auf Freigabe | zwei Haar-Puffs | dunkelbraun `#2b1d16` | Sweatshirt mint `#8fd1b4`, Jogger grau `#b9b6b0` | Lila `#7a5cc8` | goldene Creolen, lila Haargummis | 1 : 4, klein, rund | Stufe 4 `#c68a62` | dunkelbraun `#4a2e1c` |
| **Mika** (Testfigur Stilprobe, `src/stile/richtungen.ts`) | Turnaround in Stil D fertig, wartet auf Freigabe | zerzaustes Kurzhaar, keine Kopfbedeckung | silber-flieder `#c9c3d6` | Pullover ochsenblut `#7a2e35`, Cargohose sand `#b8a27c` | Kobalt `#3b5bd6` | Uhr, kobaltblaues Handy, kobalt Socken | 1 : 5, mittel | Stufe 3 `#dba783` | graugrün `#7d8f6a` |
| **Thiago** | Turnaround in Stil D fertig, wartet auf Freigabe | langer schräger Pony über dem rechten Auge, Kapuze hinten | blauschwarz `#1c1f2a` | Hoodie dunkelgrün `#2f4a3a`, Cargohose `#34343a` | Cyan `#4fb3c8` | Kabel-Kopfhörer, cyan Socken | 1 : 5, groß, dünn | Stufe 6 `#6e4429` | bernstein `#9a6a2a` |

Code: `src/cast/cast.ts` (Daten), `src/cast/Figure.tsx` (Baukasten). Render: `npm run render:cast` → `out/cast/`.

## Orte – vor jeder Szene
- **Bevor eine Szene geschrieben wird**, bekommt jeder Ort einen Plan: `locations/<ort>/plan.json` → daraus `plan.md` + `plan.png`.
- Inhalt: Maße, jede Wand, jede Tür (**inkl. Aufschlagrichtung nach innen/außen**), jedes Fenster, jede Treppe, jedes Möbelstück, die Wege jeder Figur und die Kameraposition für jede Einstellung.
- Prüfen: `python3 scripts/plan_tool.py locations/<ort>`. Wege werden zentimeterweise mit Körperradius geprüft: **nie durch Wände oder Möbel** (Wände nur durch Türöffnungen). Bei Fehlern wird `plan.md` nicht geschrieben – erst den Plan korrigieren, dann die Szene.
- Szene und Animation verwenden genau die Koordinaten aus `plan.json` (Sitzplätze, Wege, Kameras).

## Stimmen (ElevenLabs) – für jedes Video
- **Alle Stimmen im Video sprechen Deutsch** (`"language": "de"`), auch wenn mit mir auf Vietnamesisch kommuniziert wird. Die Pipeline bricht bei jeder anderen Sprache ab.
- **Schlüssel:** nur aus der Umgebungsvariable `ELEVENLABS_API_KEY`. **Niemals ausgeben, niemals in eine Datei schreiben** (auch nicht in Logs, `.env`, `voices.json` oder Commits).
  - In der Cloud-Umgebung liegt der Schlüssel als **Netzwerk-Secret für `api.elevenlabs.io` im Header `xi-api-key`** (nicht `Authorization: Bearer` – das lehnt ElevenLabs ab). Der Code schickt dann nur den Platzhalter `proxy-injected`, der Proxy setzt den echten Wert ein.
- Szene anlegen: `scenes/<id>/script.md` (Zeilen `@SPRECHER [tags]: Text`) + `scenes/<id>/scene.json` (Sprache, Sprecher → Figur, Geschlecht, Alter, Persönlichkeit).
  - Alternativ `scenes/<id>/lines.json`: `{"language": "vi", "voices": {"SPRECHER": "<voice_id>"}, "lines": [["id", "SPRECHER", "[tag] Text"]]}`. Echte voice_ids werden übernommen, Platzhalter wie `voice-id-1` per Suche besetzt.
  - Stimmprofile (Geschlecht, Alter, Persönlichkeit) je Sprecher: `scenes/speakers.json`.
- **Emotions-Tags auf Deutsch** in jeder Zeile (`@LOTTE [panisch]: …`). Die Pipeline übersetzt sie für `eleven_v3` über `TAG_DE_EN` ins Englische; unbekannte Tags werden nicht ans Modell geschickt (Warnung → Tabelle ergänzen).
- **Gemurmel/Hintergrundstimmen** in eigener Datei (`crowd.md`, IDs `M01…`, `## Beat N` = Abschnitt), eigene Sprecher mit eigenen Stimmen; in `scene.json` → `"script": ["script.md", "crowd.md"]`.
- **Zeitleiste aus echten Audiolängen:** `python3 scripts/build_timeline.py scenes/<id>` → `timeline.json` + `out/audio/<id>/dialog_mix.wav` (misst Sprachbeginn/-ende, prüft 2–4 s pro Zeile und 1:45–2:15).
- Ablauf: `python3 scripts/voice_pipeline.py all scenes/<id>`
  1. In der ElevenLabs-Stimmbibliothek nach Stimmen **in der Sprache des Videos** suchen.
  2. **Jede Figur bekommt eine eigene Stimme** (passend zu Alter, Geschlecht, Persönlichkeit), keine Stimme doppelt.
  3. Auswahl in `scenes/<id>/voices.json` speichern.
  4. Jede Zeile mit dem **neuesten Modell, das Audio (TTS) kann** und die Sprache unterstützt (Rangfolge in `TTS_PREFERENCE`, z. B. `eleven_v3` mit Audio-Tags).
  5. Jede Datei **transkribieren** und mit dem Skript vergleichen. Zeilen mit fehlenden oder falschen Wörtern **neu erzeugen** (bis 4 Versuche). Bericht: `out/audio/<id>/report.json`.
- Dieselbe Figur behält in allen Videos ihre Stimme (aus früherer `voices.json` übernehmen).

## Kamera und Hände
- Hände tun immer etwas: Handy, Tür, Geländer. Nie eine erstarrte Hand.

## Fehler, die nie wieder passieren
- **Bilder aus dem Chat sind keine Dateien.** Referenzen immer als Dateien ins Projekt legen (GitHub-Repo), nie nur im Chat.
- **Haarschale kleiner als der Schädel** → Haut sticht am Scheitel durch. Haarschalen immer ≥ 8 % größer als der Kopf.
- **Haarsträhnen enden genau an der Haarschale** → Topfschnitt-Look. Strähnen müssen über die Kante hinausragen.
- **Harter Glanz auf großen Flächen** (Facetten, dunkles Haar) → grauer Fleck. Glanz auf dunklem Haar niedrig halten.
- **Sommersprossen oder Details auf dem Augenweiß** → bei großen Augen Details unterhalb der Augen platzieren.
- **Nahaufnahme zu eng** → Kopfbedeckung abgeschnitten. Vor dem Rendern den Kopf samt Kopfbedeckung ins Bild einpassen.
- **Seitliche Haarspitzen wirken wie Hörner** → Spitzen nach unten fallen lassen, nicht waagerecht abstehen.
- **Kopf sitzt direkt auf dem Oberteil** → Hals muss sichtbar sein.
- **Ohren unter der Haarschale versteckt**, obwohl der Stil abstehende Ohren will → Ohren außerhalb der Haarschale ansetzen.
- **Randlichter zu breit** → halbes Gesicht blau. Randlicht nur als schmale Kante, auf Haut abgeschwächt.
- **Kapuze über dem Kopf wirkt wie ein Helm** (Kugelschale + Ring). Kapuzen nur hinten liegend bauen.
- **Haarschalen unter Kopfbedeckung stechen durch** → unter Kapuze/Mütze nur sichtbare Strähnen bauen.
- **Haar-Kegel um ihre Mitte verankert** → Strähne steht nach oben ab. Strähnen am Ansatz verankern, Spitze in Fallrichtung.
- **Brille mit Outline im Comic-Stil** → Gestell wird zur Banditenmaske. Dünne dunkle Teile ohne Outline bauen.
- **Helle, beige Haare im 2-Ton-Stil** → warmer Schattenton sieht aus wie Haut, Kopf wirkt halb kahl. Haarfarben mit klarem Abstand zum Hautton wählen.
- **4K-Render mit mehreren parallelen Tabs** (`--concurrency` > 1 bei `--scale=2`) → Software-WebGL liefert kaputte, gekachelte Bilder. 3D-Szenen in 4K immer mit `--concurrency=1` rendern und das Raw-Video vor dem Fisheye prüfen.
